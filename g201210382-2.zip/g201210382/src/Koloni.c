/**
*
* @author Mehmet ATAŞ mehmet.atas5@ogr.sakarya.edu.tr
* @since 15.05.2023
* <p>
* 	Kolonilerin oluşturuluduğu koloni kurucu, yıkıcı ve ekrana yazdırma fonk. içeren dosya
* </p>
*/
#include "Koloni.h"

// kolonileri olusturmamizi saglayan koloni kurucu fonksiyonu
Koloni KoloniKurucu(int nufus,int sembol,int savas_degeri,int savas_kaybetme,int savas_kazanma,int yemek){
	Koloni this =(Koloni)malloc(sizeof(struct KOLONI));// koloni icin bellekte yer ayriliyor
	this->nufus=nufus;
	this->sembol=sembol;
	this->savas_degeri=savas_degeri;
	this->savas_kaybetme=savas_kaybetme;
	this->savas_kazanma=savas_kazanma;
	this->yemek=yemek;
	this->koloniYikiciFonksiyon = &KoloniYikiciFonksiyon;
	this->ekranaYazdir = &EkranaYazdir;
	if (nufus <= 0 || yemek <= 0)
        this->oyundaMi = false;
    else
        this->oyundaMi = true;
	return this;
}
void EkranaYazdir(const Koloni this,int deger){ // Koloninin degerlerini ekrana yazdiran fonksiyon
	if(deger<=1){
		if (this->nufus <= 0 ||this->yemek <= 0) {
			printf("  %-6c  %-12s   %-14s   %-8s  %-8s\n", this->sembol, "--", "--", "--", "--");// yasami sona eren kolonilerin ekrana yazdirilmasi
		}
		else {
			printf("  %-6c  %-12d   %-14d   %-8d  %-8d\n", this->sembol, this->nufus, this->yemek, this->savas_kazanma, this->savas_kaybetme);
		}
	}
	else
		printf("  %-6c  %-12d   %-14d   %-8d  %-8d\n", this->sembol, this->nufus, this->yemek, this->savas_kazanma, this->savas_kaybetme);
	
}
// koloni yapisinin yikici fonksiyonu
void KoloniYikiciFonksiyon(Koloni this){
    if(this==NULL) return;
	free(this);
}