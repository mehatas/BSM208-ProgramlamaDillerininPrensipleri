/**
*
* @author Mehmet ATAŞ mehmet.atas5@ogr.sakarya.edu.tr
* @since 16.05.2023
* <p>
*  Taktik yapısından kalıtım alan btaktik yapısının kurucu, yıkıcı ve soyut olarak olusturulan savas fonk. iceren dosya
* </p>
*/
#include "BTaktik.h"
// bTaktik kurucu fonksiyon
bTaktik bTaktikOlustur(){
	bTaktik this;
	this = (bTaktik)malloc(sizeof(struct BTAKTIK));//  bTaktik icin bellekte yer ayrılıyor
	this->super = TaktikKurucuFonksiyon();
	this->super->Savas = &Savas;
	this->yoket = &bTaktikYoket;
	return this;
}
int Savas(const bTaktik this){
	int a,b;
	a = rand() % 500; // 0-500 arası rastgele sayı
	b = rand() % 100; // 0-100 arası rastgele sayı

	return ((a*(b*15))/8)%1001;//0-1000 arasında rastgele bir deger dondurur
}
// btaktik yikici fonk.
void bTaktikYoket(const bTaktik this){
	if(this == NULL) return;
	this->super->taktikYikiciFonksiyon(this->super);
	free(this);
}
