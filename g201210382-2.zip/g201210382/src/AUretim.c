/**
*
* @author Mehmet ATAŞ mehmet.atas5@ogr.sakarya.edu.tr
* @since 16.05.2023
* <p>
*  Uretim yapısından kalıtım alan auretim yapısının kurucu, yıkıcı ve soyut olarak olusturulan uretim fonk. iceren dosya
* </p>
*/
#include "AUretim.h"
// aUretim kurucu fonk.
aUretim aUretimOlustur(){
	aUretim this;
	this = (aUretim)malloc(sizeof(struct AURETIM));// auretim icin bellekte yer ayrılıyor
	this->super = UretimKurucuFonksiyon();
	this->super->UretimSoyut  = &uretimA;
	this->yoket = &aUretimYoket;
	return this;
}
int uretimA(const aUretim this){
	int a = rand() % 100 + 1;
	int b = rand() % 250+ 1;
	int c = rand() % 500 + 1;
	int d = rand() % 1000 + 1;
	
	return ((a*d)+(b*c))%10+1;//1-10 arasında rastgele bir deger dondurur
}
// aUretim yikici fonk.
void aUretimYoket(const aUretim this){
	if(this == NULL) return;
	this->super->uretimYikiciFonksiyon(this->super);
	free(this);
}
