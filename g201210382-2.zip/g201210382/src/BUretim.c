/**
*
* @author Mehmet ATAŞ mehmet.atas5@ogr.sakarya.edu.tr
* @since 16.05.2023
* <p>
*  Uretim yapısından kalıtım alan buretim yapısının kurucu, yıkıcı ve soyut olarak olusturulan uretim fonk. iceren dosya
* </p>
*/
#include "BUretim.h"
// bUretim kurucu fonksiyon
bUretim bUretimOlustur(){
	bUretim this;
	this = (bUretim)malloc(sizeof(struct BURETIM));//  buretim icin bellekte yer ayrılıyor
	this->super = UretimKurucuFonksiyon();
	this->super->UretimSoyut= &uretimB;
	this->yoket = &bUretimYoket;
	return this;
}
int uretimB(const bUretim this){
	int y = 8;
	int x = rand()%10;
	int z = rand()%1000;
	return ((z/(5*y))+x)%10+1;//1-10 arasında rastgele bir deger dondurur
}
// bUretim yikici fonk.
void bUretimYoket(const bUretim this){
	if(this == NULL) return;
	this->super->uretimYikiciFonksiyon(this->super);
	free(this);
}
