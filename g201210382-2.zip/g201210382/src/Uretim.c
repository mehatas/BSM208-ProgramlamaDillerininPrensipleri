/**
*
* @author Mehmet ATAŞ mehmet.atas5@ogr.sakarya.edu.tr
* @since 16.05.2023
* <p>
* 	Uretim yapsının oluşturuluduğu uretim kurucu, yıkıcı ve uretim fonk. içeren dosya
* </p>
*/
#include "Uretim.h"
Uretim UretimKurucuFonksiyon(){	
	Uretim this;
	this = (Uretim)malloc(sizeof(struct URETIM));// uretim yapisi icin bellekte yer ayriliyor
	this->UretimFonksiyonu = &UretimFonksiyonu;
	this->uretimYikiciFonksiyon = &UretimYikiciFonksiyon;
	return this;
}
//soyut olarak olusuturlacak olan uretim fonksiyonun urettiği değerin donduruldugu fonksiyon
int UretimFonksiyonu(const Uretim this,void* p){
	return this->UretimSoyut(p);
}
void UretimYikiciFonksiyon(Uretim this){
	 if(this==NULL) return;
	 free(this);
}