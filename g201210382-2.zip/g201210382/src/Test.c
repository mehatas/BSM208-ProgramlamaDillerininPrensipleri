/**
*
* @author Mehmet ATAŞ mehmet.atas5@ogr.sakarya.edu.tr
* @since 19.05.2023
* <p>
* 	Main fonksiyonu, uygulamanın ana girdi noktası
* </p>
*/
#include "Oyun.h"
// main fonksiyonu
int main() {
	Oyun oyun = OyunKurucuFonksiyon();
	Koloni* koloniler = (Koloni*)malloc(sizeof(Koloni)*oyun->satir);
	oyun->oyunBaslat(oyun, koloniler);
	oyun->oyunYikiciFonksiyon(oyun);
	free(koloniler);
    return 0;
}
