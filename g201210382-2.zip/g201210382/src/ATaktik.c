/**
*
* @author Mehmet ATAŞ mehmet.atas5@ogr.sakarya.edu.tr
* @since 16.05.2023
* <p>
*  Taktik yapısından kalıtım alan ataktik yapısının kurucu, yıkıcı ve soyut olarak olusturulan savas fonk. iceren dosya
* </p>
*/
#include "ATaktik.h"

// ataktik kurucu fonk.
aTaktik aTaktikOlustur(){
	aTaktik this;
	this = (aTaktik)malloc(sizeof(struct ATAKTIK));//  aTaktik icin bellekte yer ayrılıyor
	this->super = TaktikKurucuFonksiyon();
	this->super->Savas = &savas;
	this->yoket = &aTaktikYoket;
	return this;
}
int savas(const aTaktik this){
	int x , y , z ;
	x = rand() % 100; // 0-100 arası rastgele sayı
	y = rand() % 100; // 0-100 arası rastgele sayı
	z = rand() % 100; // 0-100 arası rastgele sayı
	return ((y * z)+(3*x+10))%1001;//0-1000 arasında rastgele bir deger dondurur
}
// aTaktik yikici fonk.
void aTaktikYoket(const aTaktik this){
	if(this == NULL) return;
	this->super->taktikYikiciFonksiyon(this->super);
	free(this);
}
