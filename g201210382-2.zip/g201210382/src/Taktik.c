/**
*
* @author Mehmet ATAŞ mehmet.atas5@ogr.sakarya.edu.tr
* @since 16.05.2023
* <p>
* 	Taktik yapsının oluşturuluduğu taktik kurucu, yıkıcı ve savas fonk. içeren dosya
* </p>
*/
#include "Taktik.h"

Taktik TaktikKurucuFonksiyon(){
	Taktik this;
	this = (Taktik)malloc(sizeof(struct TAKTIK)); // taktik icin bellekte yer ayriliyor
	this->SavasFonksiyonu = &SavasFonksiyonu;
	this->taktikYikiciFonksiyon = &TaktikYikiciFonksiyon;
	return this;
}
int SavasFonksiyonu(const Taktik this,void* p){
	return this->Savas(p);
}
void TaktikYikiciFonksiyon(Taktik this){
   if(this==NULL) return;
   free(this);
	
}