/**
*
* @author Mehmet ATAŞ mehmet.atas5@ogr.sakarya.edu.tr
* @since 19.05.2023
* <p>
* 	Ödevde istenen durumların simüle edildiği bir takım fonksiyonlar içeren oyun kaynak dosyası
* </p>
*/
#include "Oyun.h"
#define MAX_SIZE 1000

//Kullanicinin girdiği verideki gecersiz karakterleri kontrol eden karakterKontrol fonksiyonu (private benzetimi.)
int karakterKontrol(const char* str) {
    while (*str) {
        if (!isdigit(*str)) {
            return 1; // Sayısal olmayan karakterler var
        }
        str++;
    }
    return 0; // Geçerli bir sayı
}

//her turda kolonilere birbirinden farkli bir rastgele sembol atamak icin kullanilan dizikaristir fonk. (private benzetimi.)
void diziKaristir(int *sembols, int size) {
    for (int i = size - 1; i > 0; i--) {
        int j = rand() % (i + 1);
        int temp = sembols[i];
        sembols[i] = sembols[j];
        sembols[j] = temp;
    }
}

Oyun OyunKurucuFonksiyon(){ // Oyun kurucu fonksiyonu
    Oyun this = (Oyun)malloc(sizeof(struct OYUN)); //Oyun için bellekte yer ayrılıyor.
    this->oyunBaslat = &OyunBaslat;
    this->oyunYikiciFonksiyon = &OyunYikiciFonksiyon;
    this->satir=0;
    int count = 0; // Girilen sayıların toplam sayısı
	system("@cls||clear");
    printf("Lutfen sayilari giriniz: ");
    char input[1000]; // Kullanıcıdan alınan girişin geçici olarak saklandığı dizi
    fgets(input, sizeof(input), stdin);
    char* token = strtok(input, " \n");
	while (token != NULL && count < MAX_SIZE) {
		int number = atoi(token); 
		if (number != 0 && !karakterKontrol(token)) {
			this->dizi[count] = number; // Geçerli bir sayıysa diziye eklenir
			count++;
		}
		token = strtok(NULL, " \n");
	}
	free(token);
	this->satir=count;
    return this;
}

void OyunBaslat(const Oyun this,Koloni* koloniler){ // Oyunu baslatan fonksiyon

	int sembols [] = {1,2,3,4,5,6,17,18,19,20,21,22,23,24,25,26,28,29,30,31,33,34,35,36,37,38,39,40,41,42,43,44,46,47,58,59,60,61,62,63,64,91,92,93,94,96,101,109,122,123,124,125,126,3009,184,200,174,169,170,168,225,231,241,254,248,189,190,206,236}; // rastgele sembol atanması
	int sembolsBoyutu =  sizeof(sembols) / sizeof(sembols[0]);
	srand(time(NULL));
	diziKaristir(sembols, sembolsBoyutu); // Sembol dizisini karıştır
	//kullanicidan alinan sayilarla koloniler olusturuluyor
    for (int i = 0; i < this->satir; i++) {
		int savas_kazanma = 0;
		int savas_kaybetme = 0;
		int savas_degeri=0;
		int sembol = sembols[i % sembolsBoyutu]; // Mod işlemi ile sıradaki sembolü al
		int yemekMiktari = this->dizi[i] * this->dizi[i];// baslangic yemek stogu mevcut populasyonun karesi kadar ataniyor
		int nufus=this->dizi[i];
		koloniler[i] = KoloniKurucu(nufus, sembol,savas_degeri,savas_kaybetme,savas_kazanma, yemekMiktari);// koloniler olusturuluyor
    }
	  
	int round = 1;
    while (1) {

		system("@cls||clear");		
		
		// Her turda popülasyonun ve yemek stoğunun güncellenmesi	
		for (int i = 0; i < this->satir; i++) {
			if (koloniler[i]->nufus <= 0||koloniler[i]->yemek <= 0){
				continue;
			}
			else{
				// her koloni rastgele bir uretim teknigi kullanir
				if(i%2==0){
					aUretim aUret = aUretimOlustur();
					koloniler[i]->yemek+=aUret->super->UretimFonksiyonu(aUret->super,aUret);
					aUret->yoket(aUret);
				}
				else {
					bUretim bUret = bUretimOlustur();
					koloniler[i]->yemek+= bUret->super->UretimFonksiyonu(bUret->super,bUret);
					bUret->yoket(bUret);	
				}
				koloniler[i]->nufus += koloniler[i]->nufus *0.2; // nufusta %20 artış
				koloniler[i]->yemek -= koloniler[i]->nufus * 2; // yemek miktarinda GüncelPopülasyon x 2 kadar azalma
			}
		}	
		
		int totalBattles = (this->satir * (this->satir - 1)) / 2; // Toplam savaş sayısı
		int currentBattles = 0; // Şu ana kadar gerçekleşen savaş sayısı

		
		int aliveColonies = this->satir;
		while (aliveColonies > 1 && currentBattles < totalBattles) {
			
			aliveColonies = 0;
			for (int z = 0; z < this->satir; z++) {
				if (koloniler[z]->nufus > 0 && koloniler[z]->yemek > 0) {
					aliveColonies++;
				}
			}
			if (aliveColonies <= 1) {
				for (int z = 0; z < this->satir; z++) {
					if (koloniler[z]->nufus > 0 && koloniler[z]->yemek > 0) {
						koloniler[z]->savas_kazanma++;
					}
				}
				break; // Sadece bir koloni hayatta kaldıysa döngüyü sonlandır
			}
			// Her turda tüm koloniler birbirleriyle savasir, savas sirasindaki artim/azaltim işlemleri yapılıyor
			for (int i = 0; i < this->satir; i++) {
				for (int j = i+1; j < this->satir; j++) {
				
					if ((koloniler[i]->nufus <= 0||koloniler[i]->yemek <= 0) && (koloniler[j]->nufus <=0 || koloniler[j]->yemek <= 0)){
							koloniler[j]->savas_kaybetme++;
							koloniler[i]->savas_kaybetme++;	
							currentBattles++;						
					}
					else if ((koloniler[i]->nufus <= 0||koloniler[i]->yemek <= 0) && (koloniler[j]->nufus>0  && koloniler[j]->yemek > 0)){
							koloniler[j]->savas_kazanma++;
							koloniler[i]->savas_kaybetme++;
							currentBattles++;
					}
					else if ((koloniler[j]->nufus <= 0||koloniler[j]->yemek <= 0) && (koloniler[i]->nufus>0  && koloniler[i]->yemek > 0)){
							koloniler[i]->savas_kazanma++;
							koloniler[j]->savas_kaybetme++;
							currentBattles++;
					}
					else{
						// Her koloni için savaş değerini döndürme
						aTaktik a = aTaktikOlustur();
						koloniler[i]->savas_degeri=a->super->SavasFonksiyonu(a->super,a);			
					
						bTaktik b = bTaktikOlustur();
						koloniler[j]->savas_degeri = b->super->SavasFonksiyonu(b->super,b);
								
					// Savaş kazananını belirleme
						if (koloniler[i]->savas_degeri > koloniler[j]->savas_degeri) {
							koloniler[i]->savas_kazanma++;
							koloniler[j]->savas_kaybetme++;
							int kayip = 1000/(koloniler[i]->savas_degeri-koloniler[j]->savas_degeri);
							int loss = (koloniler[j]->nufus * kayip)/100; 
							koloniler[j]->nufus -= loss;
							int transfer = (koloniler[j]->yemek * kayip)/100; 
							koloniler[j]->yemek -= transfer;
							koloniler[i]->yemek += transfer; 
						}
						else if (koloniler[j]->savas_degeri > koloniler[i]->savas_degeri) {
							koloniler[j]->savas_kazanma++;
							koloniler[i]->savas_kaybetme++;
							int kayip = 1000/(koloniler[j]->savas_degeri-koloniler[i]->savas_degeri);
							int loss = (koloniler[i]->nufus * kayip)/100; 
							koloniler[i]->nufus -= loss;
							int transfer = (koloniler[i]->yemek * kayip)/100; 
							koloniler[i]->yemek -= transfer;
							koloniler[j]->yemek += transfer; 
						}
						else {
							// Çekilen sayi esit olmasi durumunda popülasyonu fazla olan kazanir
							if (koloniler[i]->nufus > koloniler[j]->nufus) {
								koloniler[i]->savas_kazanma++;
								koloniler[j]->savas_kaybetme++;
							}
							else if (koloniler[j]->nufus > koloniler[i]->nufus) {
								koloniler[j]->savas_kazanma++;
								koloniler[i]->savas_kaybetme++;
							}
							else {
								// Popülasyonlar da eşitse rastgele biri kazanır
								if (rand() % 2 == 0) {
									koloniler[j]->savas_kazanma++;
									koloniler[i]->savas_kaybetme++;
								}
								else {
									koloniler[i]->savas_kazanma++;
									koloniler[j]->savas_kaybetme++;
								}
							}
						}		
						a->yoket(a);
						b->yoket(b);
						currentBattles++;					
					}
					if (currentBattles >= totalBattles) {
						break; // Toplam savaş sayısına ulaşıldıysa döngüyü sonlandır
					}	
				}
			}	
		}
		
		
		// Hayati devam eden kolonilerin adedi bulunuyor
		int num_alive = 0;
		for (int i = 0; i < this->satir; i++) {
			if (koloniler[i]->nufus <= 0||koloniler[i]->yemek <= 0);
			else
				num_alive++;	
		}

		// tek bir koloni kaldiysa son veriler ekrana yazdirilir, donguden cikilir, simulasyon son bulur
		if (num_alive <= 1){
			printf("----------------------------------------------------------\n");
			printf("Tur Sayisi %d:\n", round);
			printf("KOLONI  POPULASYON     YEMEK STOGU      KAZANMA   KAYBETME\n");		
			for (int i = 0; i < this->satir; i++) {
				if (koloniler[i]->nufus <= 0||koloniler[i]->yemek <= 0){
					if((koloniler[i]->savas_kazanma+koloniler[i]->savas_kaybetme)==(round*(this->satir-1)))
						koloniler[i]->savas_kaybetme-= this->satir-1;
				}
				else{
					if((koloniler[i]->savas_kazanma+koloniler[i]->savas_kaybetme)==(round*(this->satir-1)))
					koloniler[i]->savas_kazanma-= this->satir-2;
				}					
				koloniler[i]->ekranaYazdir(koloniler[i],num_alive);	
			}
			printf("----------------------------------------------------------\n");		
			break ;
		}
	
	
		// her turda veriler ekrana yazdiriliyor
		printf("----------------------------------------------------------\n");
        printf("Tur Sayisi %d:\n", round);
  		printf("KOLONI  POPULASYON     YEMEK STOGU      KAZANMA   KAYBETME\n");
		for (int i = 0; i < this->satir; i++) {
			koloniler[i]->ekranaYazdir(koloniler[i],num_alive);
		}
		printf("----------------------------------------------------------\n");
	
	
	
		round++; // Bir sonraki tur için round değişkenini arttır
	}
    // oyun icerisinde olusturulan koloniler koloni yikici fonk. yardimiyla iade ediliyor.
	for (int i = 0; i < this->satir; i++) {
		koloniler[i]->koloniYikiciFonksiyon(koloniler[i]);
	}
}

void OyunYikiciFonksiyon(Oyun this){ // Oyun yıkıcı fonksiyonu
   if(this==NULL) return;
   free(this);
}