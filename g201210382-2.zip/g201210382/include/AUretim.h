/**
*
* @author Mehmet ATAŞ mehmet.atas5@ogr.sakarya.edu.tr
* @since 16.05.2023
* <p>
* 	aUretim yapısı için gerekli header sınıfı
* </p>
*/
#ifndef AURETIM_H
#define AURETIM_H

#include "Uretim.h"

struct AURETIM{
	Uretim super;// Uretim yapısından kalıtım

	void(*yoket)(struct AURETIM*);
};
typedef struct AURETIM* aUretim;

aUretim aUretimOlustur();
int uretimA(const aUretim);// soyut olarak olusturulan uretim fonksiyonu
void aUretimYoket(const aUretim);// yikici fonksiyon


#endif
