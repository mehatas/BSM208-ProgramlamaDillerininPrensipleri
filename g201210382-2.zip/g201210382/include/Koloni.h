/**
*
* @author Mehmet ATAŞ mehmet.atas5@ogr.sakarya.edu.tr
* @since 15.05.2023
* <p>
* 	Koloni yapısı için gerekli header sınıfı
* </p>
*/
#ifndef KOLONI_H
#define KOLONI_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

//boolean türü benzetimi
typedef enum{
	false,true
} bool;

struct  KOLONI{

	void (*koloniYikiciFonksiyon)(struct KOLONI*);
	
    void (*ekranaYazdir)(struct KOLONI*,int);
		
	int nufus;
    int sembol;
    int yemek;
	int savas_degeri;
	int savas_kazanma;
	int savas_kaybetme;
	
	bool oyundaMi;

};

typedef struct KOLONI* Koloni;


Koloni KoloniKurucu(int,int,int,int,int,int); // kolonileri olusturmamizi saglayan koloni kurucu fonksiyonu
void EkranaYazdir(const Koloni,int);
void KoloniYikiciFonksiyon(Koloni); // koloni yapisinin yikici fonksiyonu




#endif