/**
*
* @author Mehmet ATAŞ mehmet.atas5@ogr.sakarya.edu.tr
* @since 16.05.2023
* <p>
* 	aTaktik yapısı için gerekli header sınıfı
* </p>
*/
#ifndef ATAKTIK_H
#define ATAKTIK_H

#include "Taktik.h"
struct ATAKTIK{
	Taktik super; // Taktik yapısından kalıtım
	void(*yoket)(struct ATAKTIK*);
};
typedef struct ATAKTIK* aTaktik;

aTaktik aTaktikOlustur();
int savas(const aTaktik);// soyut olarak olusturulacak savas fonk.
void aTaktikYoket(const aTaktik); // yikici fonk.

#endif
