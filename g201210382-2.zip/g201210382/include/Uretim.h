/**
*
* @author Mehmet ATAŞ mehmet.atas5@ogr.sakarya.edu.tr
* @since 16.05.2023
* <p>
* 	Üreim yapısı için gerekli header sınıfı
* </p>
*/
#ifndef URETIM_H
#define URETIM_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

struct URETIM{
	void (*uretimYikiciFonksiyon)(struct URETIM*);
	int (*UretimFonksiyonu)(struct URETIM*,void*);
	int(*UretimSoyut)();// soyut olarak olusturulan uretim fonksiyonu
};

typedef struct URETIM* Uretim;


Uretim UretimKurucuFonksiyon();
int UretimFonksiyonu(const Uretim,void*);
void UretimYikiciFonksiyon(Uretim);


#endif