/**
*
* @author Mehmet ATAŞ mehmet.atas5@ogr.sakarya.edu.tr
* @since 16.05.2023
* <p>
* 	bTaktik yapısı için gerekli header sınıfı
* </p>
*/
#ifndef BTAKTIK_H
#define BTAKTIK_H

#include "Taktik.h"

struct BTAKTIK{
	Taktik super; // Taktik yapısından kalıtım

	void(*yoket)(struct BTAKTIK*);//yıkıcı fonksiyon
};
typedef struct BTAKTIK* bTaktik;

bTaktik bTaktikOlustur();
int Savas(const bTaktik);// soyut olarak olusturulan savas fonksiyonu
void bTaktikYoket(const bTaktik);

#endif
