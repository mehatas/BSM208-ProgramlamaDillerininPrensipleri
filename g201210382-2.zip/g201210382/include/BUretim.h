/**
*
* @author Mehmet ATAŞ mehmet.atas5@ogr.sakarya.edu.tr
* @since 16.05.2023
* <p>
* 	BURETIM yapısı için gerekli header sınıfı
* </p>
*/
#ifndef BURETIM_H
#define BURETIM_H

#include "Uretim.h"

struct BURETIM{
	Uretim super;// Uretim yapısından kalıtım
	void(*yoket)(struct BURETIM*);
};

typedef struct BURETIM* bUretim;

bUretim bUretimOlustur();
int uretimB(const bUretim);// soyut olarak olusturulan uretim fonksiyonu
void bUretimYoket(const bUretim);// yikici fonksiyonu


#endif
