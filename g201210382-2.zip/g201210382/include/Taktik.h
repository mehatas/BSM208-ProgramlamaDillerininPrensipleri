/**
*
* @author Mehmet ATAŞ mehmet.atas5@ogr.sakarya.edu.tr
* @since 16.05.2023
* <p>
* 	Taktik yapısı için gerekli header sınıfı
* </p>
*/
#ifndef TAKTIK_H
#define TAKTIK_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

struct TAKTIK{	
	void (*taktikYikiciFonksiyon)(struct TAKTIK*);
	int (*SavasFonksiyonu)(struct TAKTIK*,void*);

	int(*Savas)();//savas
	
};
typedef struct TAKTIK* Taktik;


Taktik TaktikKurucuFonksiyon();
int SavasFonksiyonu(const Taktik,void*);
void TaktikYikiciFonksiyon(Taktik);


#endif
