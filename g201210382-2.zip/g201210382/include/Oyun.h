/**
*
* @author Mehmet ATAŞ mehmet.atas5@ogr.sakarya.edu.tr
* @since 19.05.2023
* <p>
* 	Oyun yapısı için gerekli header sınıfı
* </p>
*/
#ifndef OYUN_H
#define OYUN_H

#include <ctype.h>
#include "Koloni.h"
#include "Uretim.h"
#include "Taktik.h"
#include "ATaktik.h"
#include "BTaktik.h"
#include "AUretim.h"
#include "BUretim.h"
#define MAX 1000


struct OYUN{
	void (*oyunBaslat)(struct OYUN*, Koloni*);
	void (*oyunYikiciFonksiyon)(struct OYUN*); 
	int satir;
	int dizi[MAX];// kullanicidan alinacak sayilarin saklanacagi dizi
};
typedef struct OYUN* Oyun;

Oyun OyunKurucuFonksiyon();// oyun kurucu fonksiyon
void OyunBaslat(const Oyun,Koloni*);// oyun baslatan fonksiyon
void OyunYikiciFonksiyon(Oyun);// oyun yikici fonk.

#endif