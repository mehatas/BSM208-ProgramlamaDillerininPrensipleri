/**
*
* @author Mehmet ATAS mehmet.atas5@ogr.sakarya.edu.tr
* @since 08.04.2023
* <p>
* Main fonksiyonu
* </p>
*/
package G201210382;

public class Main {

	public static void main(String[] args) {
		Analyser.analyser(args);
	}

}
