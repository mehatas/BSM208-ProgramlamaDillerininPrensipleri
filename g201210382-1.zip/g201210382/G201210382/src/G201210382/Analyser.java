/**
*
* @author Mehmet ATAS mehmet.atas5@ogr.sakarya.edu.tr
* @since 09.04.2023
* <p>
* Okunan dosyadaki verileri parametre olarak alarak odevde istenen problemleri cozmemi saglayan fonksiyonları ve yapıları iceren sınıf
* </p>
*/
package G201210382;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.ArrayList;
import java.util.List;
public class Analyser {
	
	public static void analyser(String[] args) {
		
		//dosyadan veriler okunuyor
		String fileContents = ReadFile.readFile(args);

		//okutulan *.java dosyasından sınıf ismini bulmamızı saglayan kod blokları
		String classRegex = "class\\s+([a-zA-Z_$][a-zA-Z\\d_$]*)";
        Pattern classPattern = Pattern.compile(classRegex, Pattern.DOTALL);
        Matcher classMatcher = classPattern.matcher(fileContents);
        if (classMatcher.find()) {
            System.out.println("Sinif: " + classMatcher.group(1));
        }
        
		//dosyada varsa " " icerisindeki ifadeler istisani durumlara yol acabileceginden bu ifadeler siliniyor
		String newString = fileContents.replaceAll("\"(?:\\\\.|[^\\\"])*\"", "");
		
        
        //dosyadan okunan veriyi odevde istenen sekilde fonksiyonun uzerinde bulunan yorum satiriyla birlikte ayirmamizi saglayacak olan pattern 
        String functionRegex = "(?:\\s*(?:(//.*?|/\\\\*.*?\\\\\\\\*/|/\\\\*\\\\*.*?\\\\*/|public|private|protected|static)\\s+)+)?(?:(void|[\\w\\<\\>\\[\\], ]+\\s+)?([\\w]+))\\s*\\(([^)]*)\\)\\s*(?:throws\\s+(.*?))?\\s*\\{((?:[^{}]+|\\{(?:[^{}]+|\\{(?:[^{}]+|\\{(?:[^{}]+|\\{[^{}]*\\})*\\})*\\})*\\})*)\\}";

        Pattern functionPattern = Pattern.compile(functionRegex, Pattern.MULTILINE | Pattern.DOTALL);
        Matcher functionMatcher = functionPattern.matcher(newString);
        
        // dosyanin bulundugu system yolu aliniyor
        String s= System.getProperty("user.dir");
        
        // txt dosyalarının konulacağı docs klasörü başlangıçta yoksa oluşturuluyor.
        File docs = new File(s+"/docs");
        if (!docs.exists()) {
            docs.mkdir();
        }
       
    	
        String fileName = s+"\\docs\\teksatir.txt";
        String fileName1 =s+"\\docs\\coksatir.txt";
        String fileName2 =s+"\\docs\\javadoc.txt";
        
        //baslangicta, daha once olusturulan *.txt dosyaları mevcutsa mevcut dosyalar siliniyor
        File file1 = new File(fileName);
        file1.delete();
      
        File file2 = new File(fileName1);
        file2.delete();
      
        File file3 = new File(fileName2);
        file3.delete();
      
        //Dosyaya yazdırılacak verileri daha verimli bir şekilde yönetebilmek için listeler oluşturuldu
        List<String> stringListMultilineDelete = new ArrayList<String>();
        List<String> stringListMultilineInsert = new ArrayList<String>();
        List<String> stringListSingleLineDelete = new ArrayList<String>();
        List<String> stringListSingleLineInsert = new ArrayList<String>();
        List<String> stringListJavadocDelete = new ArrayList<String>();
        List<String> stringListJavadocInsert = new ArrayList<String>();
        
        while (functionMatcher.find()) {
        	int multiLineCommentcount = 0;
        	int singleLineCommentcount = 0;	
        	int javadocCommentcount = 0;
        	//fonksiyon ismi bulunuyor       
        	String functionName = functionMatcher.group(3);

        	//fonksiyon yapisi string degiskene aktariliyor
            String function = functionMatcher.group(0);
            
         
            //tek satirli, cok satirli ve javadoc yorumlarini bulmamizi saglayacak olan patternler
            Pattern singleLineComment = Pattern.compile("//.*");
            Pattern multiLineComment = Pattern.compile("/\\*.*?\\*/", Pattern.DOTALL);
            Pattern javadocComment = Pattern.compile("/\\*\\*.*?\\*/", Pattern.DOTALL);
            
            //tek satirli yorum sayisi bulunuyor ve tek satirli yorumlar teksatir.txt dosyasina yazdiriliyor
            Matcher matcherSingleLineComment = singleLineComment.matcher(function);                                   
            while (matcherSingleLineComment.find()) {
            	
            	singleLineCommentcount++;
            	String singleLineComments = matcherSingleLineComment.group();
              	String text="Fonksiyon: "+functionName+'\n'+singleLineComments+'\n'+"--------------------------------";
              	stringListSingleLineInsert.add(text);
              
              	//tek satirli yorumlar icerisinde cok satirli yorum ifadesi(/* */) varsa bu durumun kontrolü yapılıyor 
                Matcher matcherMultiLineComment1 = multiLineComment.matcher(singleLineComments);
                while (matcherMultiLineComment1.find()) {
                	 
                	multiLineCommentcount--;
	            	String multilineCommment = matcherMultiLineComment1.group();
	            	String text1="Fonksiyon: "+functionName+'\n'+multilineCommment+'\n'+"--------------------------------";
	            	stringListMultilineDelete.add(text1);
                } 
              	//tek satirli yorumlar icerisinde javadoc yorum ifadesi(/** */) varsa bu durumun kontrolü yapılıyor 
                Matcher matcherJavadocComment1 = javadocComment.matcher(singleLineComments);
                while (matcherJavadocComment1.find()) {
                	 
                	javadocCommentcount--;
                	multiLineCommentcount++;
	            	String javadocCommment = matcherJavadocComment1.group();
	            	String text2="Fonksiyon: "+functionName+'\n'+javadocCommment+'\n'+"--------------------------------";
	            	stringListJavadocDelete.add(text2);    
                } 
            }
        
            //cok satirli yorum sayisi bulunuyor ve cok satirli yorumlar coksatir.txt dosyasina yazdiriliyor
            Matcher matcherMultiLineComment = multiLineComment.matcher(function);
            while (matcherMultiLineComment.find()) {
            	
            	multiLineCommentcount++;
                String multilineComments = matcherMultiLineComment.group();
            	String text1="Fonksiyon: "+functionName+'\n'+multilineComments+'\n'+"--------------------------------";
            	stringListMultilineInsert.add(text1);
                
                
                //cok satirli ve javadoc yorumlar icerisinde // ifadesi varsa bu tek satirli yorum olarak sayildigindan bu durum kontrol ediliyor ve gerekli islemler yapiliyor
                Matcher matcherSingleLineComment1 = singleLineComment.matcher(multilineComments);        
                while (matcherSingleLineComment1.find()) {
                	
	            	singleLineCommentcount--;  
	            	String singleLine = matcherSingleLineComment1.group();
	            	String text="Fonksiyon: "+functionName+'\n'+singleLine+'\n'+"--------------------------------";
	            	stringListSingleLineDelete.add(text);
	            	 
                }  
            }            
           
            //javadoc yorum sayisi bulunuyor ve javadoc yorumlar javadoc.txt dosyasina yazdiriliyor
            Matcher matcherJavadocComment = javadocComment.matcher(function);            
            while (matcherJavadocComment.find()) {
            	
            	javadocCommentcount++;
            	multiLineCommentcount--;
                String javadocComments = matcherJavadocComment.group();      
            	String text="Fonksiyon: "+functionName+'\n'+javadocComments+'\n'+"--------------------------------";
            	stringListJavadocInsert.add(text);
            	stringListMultilineDelete.add(text);	      
     
            }     

            //bulunan degerler odevde istenen formatta ekrana yazdiriliyor.
            System.out.println("	Fonksiyon: " + functionName);
            System.out.println("			Tek satir yorum sayisi:   " + singleLineCommentcount);
            System.out.println("			Cok satirli yorum sayisi: " + multiLineCommentcount);
            System.out.println("			Javadoc yorum sayisi:     " + javadocCommentcount);
            System.out.println("----------------------------------------------------" ); 
          
        }
        
        
        // Yapılan işlemler sonucu elde edilen veriler kontrol edilip coksatirliyorumlar coksatir.txt dosyasina yazdırılıyor		
        for (String item : stringListMultilineInsert) {
            if (!stringListMultilineDelete.contains(item)) {
         	   try {
                	BufferedWriter writer = new BufferedWriter(new FileWriter(fileName1, true));
                    writer.write(item);
                    writer.newLine();
                    writer.close();
                   } catch (IOException e) {
                	   e.printStackTrace();
                }                
         	   }
         }
        // Yapılan işlemler sonucu elde edilen veriler kontrol edilip tek satirli yorumlar teksatir.txt dosyasina yazdırılıyor		
        for (String item : stringListSingleLineInsert) {
            if (!stringListSingleLineDelete.contains(item)) {
            	try {
            			BufferedWriter writer = new BufferedWriter(new FileWriter(fileName, true));
            			writer.write(item);
            			writer.newLine();
            			writer.close();       
            	} catch (IOException e) {
            		e.printStackTrace();
            	}
            }
        }
        // Yapılan işlemler sonucu elde edilen veriler kontrol edilip javadoc yorumlar javadoc.txt dosyasina yazdırılıyor		
        for (String item : stringListJavadocInsert) {
            if (!stringListJavadocDelete.contains(item)) {
            	try {
            		BufferedWriter writer = new BufferedWriter(new FileWriter(fileName2, true));   	 
            		writer.write(item);
            		writer.newLine();
            		writer.close();
            	} catch (IOException e) {
            		e.printStackTrace();
            	} 
           }
        }
         
    }		
}