/**
*
* @author Mehmet ATAS mehmet.atas5@ogr.sakarya.edu.tr
* @since 08.04.2023
* <p>
* Dosyadan verileri okumamızı sağlayan fonksiyonu iceren sınıf
* </p>
*/
package G201210382;

import java.io.BufferedReader;
import java.io.FileReader;

public class ReadFile {
	
	//dosyadan verileri okumamizi saglayan fonksiyon
	public static String readFile(String [] fileName) {
        String content = "";
        try {
        	
        	String s= System.getProperty("user.dir");
			String filePath=s+"/"+fileName[0];
            BufferedReader reader = new BufferedReader(new FileReader(filePath));          
            String line = null;
            while ((line = reader.readLine()) != null) {
            	content += line + "\n";
            }
            reader.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return content;
    }
}
