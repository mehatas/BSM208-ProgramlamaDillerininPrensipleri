/**
*
* @author Mehmet ATAŞ mehmet.atas5@ogr.sakarya.edu.tr
* @since 24.05.2023
* <p>
* 	Kullanıcıdan verileri almamızı saglayan fonksiyonu içeren sınıf
* </p>
*/
package g201210382_3;
import java.util.ArrayList;
import java.util.Scanner;

public class VerileriAl {
	 public ArrayList<Integer> verileriAl() {
	        ArrayList<Integer> liste = new ArrayList<>();
	        
	        Scanner scanner = new Scanner(System.in);
			System.out.print("Lutfen sayilari giriniz:");
			String input = scanner.nextLine();
			String[] tokens = input.split(" ");
			for (String token : tokens) {
				if (!KarakterKontrol.karakterKontrol(token)) {
					try {
						int number = Integer.parseInt(token);
						if (number != 0) {
							liste.add(number); // Geçerli bir sayıysa diziye eklenir
						}
					} catch (NumberFormatException e) {
						// Hata oluştuğunda atlamak için bir işlem yapmıyoruz
					}
				}
			}
			scanner.close();
	        // Liste nesnesini döndürün
	        return liste;
	    }

}
