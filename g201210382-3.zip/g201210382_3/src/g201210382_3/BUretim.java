/**
*
* @author Mehmet ATAS mehmet.atas5@ogr.sakarya.edu.tr
* @since 24.05.2023
* <p>
* Soyut uretim fonksiyonunun 1-10 arasında değer döndürmesini sağlayan işlemler yapılıyor, Uretim sınıfından kalıtım alınmaktadır 
* </p>
*/
package g201210382_3;
import java.util.Random;
public class BUretim extends Uretim{
	public BUretim() {
		super();
	}
	
	@Override
	public int uretim(){
		Random rand = new Random();
		 int y = 8;
		 int x = rand.nextInt(11);
		 int z = rand.nextInt(1001);
		return ((z/(5*y))+x)%10+1;//1-10 arasında rastgele bir deger dondurur
	}
}
