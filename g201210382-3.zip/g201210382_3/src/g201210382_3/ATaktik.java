/**
*
* @author Mehmet ATAS mehmet.atas5@ogr.sakarya.edu.tr
* @since 24.05.2023
* <p>
* Soyut savas fonksiyonun 0-1000 arasında değer döndürmesini sağlayan işlemler yapılıyor, Taktik sınıfından kalıtım alınmaktadır 
* </p>
*/
package g201210382_3;
import java.util.Random;
public class ATaktik extends Taktik{
	public ATaktik() {
		super();
	}
	@Override
	public int Savas(){
		Random rand = new Random();
		int x , y , z ;
		x = rand.nextInt(100); // 0-99 arası rastgele sayı
		y = rand.nextInt(100); // 0-99 arası rastgele sayı
		z = rand.nextInt(100); // 0-99 arası rastgele sayı
		return ((y * z)+(3*x+10))%1001;//0-1000 arasında rastgele bir deger dondurur
	}
}
