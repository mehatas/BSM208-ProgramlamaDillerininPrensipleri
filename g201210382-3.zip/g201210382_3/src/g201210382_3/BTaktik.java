/**
*
* @author Mehmet ATAS mehmet.atas5@ogr.sakarya.edu.tr
* @since 24.05.2023
* <p>
* Soyut savas fonksiyonun 0-1000 arasında değer döndürmesini sağlayan işlemler yapılıyor, Taktik sınıfından kalıtım alınmaktadır 
* </p>
*/
package g201210382_3;
import java.util.Random;
public class BTaktik extends Taktik{
	public BTaktik() {
		super();
	}
	
	@Override
	public int Savas(){
		Random rand = new Random();
		int a,b;
		a = rand.nextInt(501); // 0-500 arası rastgele sayı
		b = rand.nextInt(101); // 0-100 arası rastgele sayı

		return ((a*(b*15))/8)%1001;//0-1000 arasında rastgele bir deger dondurur
	}
}
