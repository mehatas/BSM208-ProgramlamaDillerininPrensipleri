/**
*
* @author Mehmet ATAS mehmet.atas5@ogr.sakarya.edu.tr
* @since 24.05.2023
* <p>
* Soyut olarak olusturulacak olan uretim fonksiyonunu iceren abstract sınıf
* </p>
*/
package g201210382_3;
public abstract class Uretim {
	public int UretimFonksiyonu(){
		return uretim();
	}
	// soyut olarak olusturulacak olan uretim fonk.
	public abstract int uretim();
}
