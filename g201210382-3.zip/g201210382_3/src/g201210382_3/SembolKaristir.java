/**
*
* @author Mehmet ATAŞ mehmet.atas5@ogr.sakarya.edu.tr
* @since 24.05.2023
* <p>
* 	Kolonilere sembol atarken kullandığımız diziyi her turda farklı farklı semboller atamak için karistirmamizi saglayan diziKaristir fonk. içeren sınıf
* </p>
*/
package g201210382_3;

import java.util.Random;

public class SembolKaristir {
	
	//parametre olarak aldığı dizinin elemanlarını rastgele olarak karıştıran fonksiyon
	public static void diziKaristir(int[] sembols) {
	    Random rand = new Random();
	    int size = sembols.length;

	    for (int i = size - 1; i > 0; i--) {
	        int j = rand.nextInt(i + 1);
	        int temp = sembols[i];
	        sembols[i] = sembols[j];
	        sembols[j] = temp;
	    }
	}

}
