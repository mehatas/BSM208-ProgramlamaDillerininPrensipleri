/**
*
* @author Mehmet ATAŞ mehmet.atas5@ogr.sakarya.edu.tr
* @since 25.05.2023
* <p>
* 	Kullanicidan koloniye ait alinan veriler yardimiyla koloniler arasindaki islemleri(savas, uretim vs ) yapmamızı sağlayan yani oyunu baslatan fonksiyonları iceren oyun sınıfı
* </p>
*/
package g201210382_3;
import java.util.Random;
import java.util.ArrayList;
public class Oyun {

	public int koloniAdet;
	
	public void OyunBaslat(){
		VerileriAl veriAl = new VerileriAl();
		ArrayList<Integer> veriListesi=veriAl.verileriAl();
		koloniAdet = veriListesi.size();
	   	Koloni[] koloniler = new Koloni[koloniAdet];
		
		int sembols [] = {1,2,3,4,5,6,17,18,19,20,21,22,23,24,25,26,28,29,30,31,33,34,35,36,37,38,39,40,41,42,43,44,46,47,58,59,60,61,62,63,64,91,92,93,94,96,101,109,122,123,124,125,126,3009,184,200,174,169,170,168,225,231,241,254,248,189,190,206,236}; // rastgele sembol atanması
	    int sembolsBoyutu = sembols.length;
	    SembolKaristir.diziKaristir(sembols); // Sembol dizisini karıştır
	    // kullanıcıdan alınan verilerle koloni nesneleri oluşturuluyor
	    for (int i = 0; i < koloniAdet; i++) {
	        int savas_kazanma = 0;
	        int savas_kaybetme = 0;
	        int savas_degeri = 0;
	        int sembol = sembols[i % sembolsBoyutu];
	        int yemekMiktari = veriListesi.get(i) * veriListesi.get(i);
	        int nufus = veriListesi.get(i);
	        Koloni obj = new Koloni(nufus, sembol, savas_degeri, savas_kaybetme, savas_kazanma, yemekMiktari);
	        koloniler[i] = obj;
	    }

	    int round = 1;
	    while (true) {
	    	
	    	//terminali temizlememizi saglayan kod blokları, her turdan sonra ekran temizlenir(butun sonucları gormek isterseniz try-catch blogunu silebilirsiniz)
	    	try {
	            if (System.getProperty("os.name").contains("Windows")) {
	                new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
	            } else {
	                System.out.print("\033[H\033[2J");
	                System.out.flush();
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    	
	    	// her turda koloniler uretim yapar, kolonin nufusu %20 artar ve koloni (populasyonx2)beslenir
	    	for (int i = 0; i < koloniAdet; i++) {
	    		koloniler[i].Uret(koloniler[i], i);
	    		koloniler[i].koloniNufus(koloniler[i]);
	    		koloniler[i].koloniBesle(koloniler[i]);
	    	}

	        int totalBattles = (koloniAdet * (koloniAdet - 1)) / 2; // Toplam savaş sayısı
			int currentBattles = 0; // Şu ana kadar gerçekleşen savaş sayısı		
			int aliveColonies = koloniAdet;
			while (aliveColonies > 1 && currentBattles < totalBattles) {
				
				aliveColonies = 0;
				for (int k = 0; k < koloniAdet; k++) {
					if (koloniler[k].nufus > 0 && koloniler[k].yemek > 0) {
						aliveColonies++;
					}
				}
				if (aliveColonies <= 1) {
					for (int k = 0; k < koloniAdet; k++) {
						if (koloniler[k].nufus > 0 && koloniler[k].yemek > 0) {
							koloniler[k].savas_kazanma++;
						}
					}
					break; // Sadece bir koloni hayatta kaldıysa döngüyü sonlandır
				}
				// Her turda tüm koloniler birbirleriyle savasir, savas sirasindaki artim/azaltim işlemleri yapılıyor
				for (int i = 0; i < koloniAdet; i++) {
					for (int j = i+1; j < koloniAdet; j++) {
					
						if ((koloniler[i].nufus <= 0||koloniler[i].yemek <= 0) && (koloniler[j].nufus <=0 || koloniler[j].yemek <= 0)){
								koloniler[j].savas_kaybetme++;
								koloniler[i].savas_kaybetme++;	
								currentBattles++;						
						}
						else if ((koloniler[i].nufus <= 0||koloniler[i].yemek <= 0) && (koloniler[j].nufus>0  && koloniler[j].yemek > 0)){
								koloniler[j].savas_kazanma++;
								koloniler[i].savas_kaybetme++;
								currentBattles++;
						}
						else if ((koloniler[j].nufus <= 0||koloniler[j].yemek <= 0) && (koloniler[i].nufus>0  && koloniler[i].yemek > 0)){
								koloniler[i].savas_kazanma++;
								koloniler[j].savas_kaybetme++;
								currentBattles++;
						}
						else{
							// Her koloni için savaş değerini döndürme
							ATaktik a = new ATaktik();
							koloniler[i].savas_degeri=a.SavasFonksiyonu();			
						
							BTaktik b = new BTaktik();
							koloniler[j].savas_degeri = b.SavasFonksiyonu();
									
						// Savaş kazananını belirleme
							if (koloniler[i].savas_degeri > koloniler[j].savas_degeri) {
								koloniler[i].savas_kazanma++;
								koloniler[j].savas_kaybetme++;
								int kayip = 1000/(koloniler[i].savas_degeri-koloniler[j].savas_degeri);				
								int loss = (koloniler[j].nufus * kayip)/100; 
								koloniler[j].nufus -= loss;
								int transfer = (koloniler[j].yemek * kayip)/100; 
								koloniler[j].yemek -= transfer;
								koloniler[i].yemek += transfer; 
							}
							else if (koloniler[j].savas_degeri > koloniler[i].savas_degeri) {
								koloniler[j].savas_kazanma++;
								koloniler[i].savas_kaybetme++;
								int kayip = 1000/(koloniler[j].savas_degeri-koloniler[i].savas_degeri);
								int loss = (koloniler[i].nufus * kayip)/100; 
								koloniler[i].nufus -= loss;
								
								int transfer = (koloniler[i].yemek * kayip)/100; 
								koloniler[i].yemek -= transfer;
								koloniler[j].yemek += transfer; 
							}
							else {
								// Çekilen savas degerlerinin esit olmasi durumunda popülasyonu fazla olan kazanir
								if (koloniler[i].nufus > koloniler[j].nufus) {
									koloniler[i].savas_kazanma++;
									koloniler[j].savas_kaybetme++;
								}
								else if (koloniler[j].nufus > koloniler[i].nufus) {
									koloniler[j].savas_kazanma++;
									koloniler[i].savas_kaybetme++;
								}
								else {
								    Random random = new Random();
									// Popülasyonlar da eşitse rastgele biri kazanır
									if (random.nextInt(100)%2 == 0) {
										koloniler[j].savas_kazanma++;
										koloniler[i].savas_kaybetme++;
									}
									else {
										koloniler[i].savas_kazanma++;
										koloniler[j].savas_kaybetme++;
									}
								}
							}		
							currentBattles++;					
						}
						if (currentBattles >= totalBattles) {
							break; // Toplam savaş sayısına ulaşıldıysa döngüyü sonlandır
						}	
					}
				}	
			}
			
			// Hayati devam eden kolonilerin adedi bulunuyor
			int num_alive = 0;
			for (int i = 0; i < this.koloniAdet; i++) {
				if (koloniler[i].nufus <= 0||koloniler[i].yemek <= 0);
				else
					num_alive++;	
			}
			// tek bir koloni kaldiysa son veriler ekrana yazdirilir, donguden cikilir, simulasyon son bulur
			if (num_alive <= 1){
				System.out.println("----------------------------------------------------------");
				System.out.println("Tur Sayisi: "+round);
				System.out.println("KOLONI  POPULASYON     YEMEK STOGU      KAZANMA   KAYBETME");		
				for (int i = 0; i < this.koloniAdet; i++) {
					if (koloniler[i].nufus <= 0||koloniler[i].yemek <= 0){
						if((koloniler[i].savas_kazanma+koloniler[i].savas_kaybetme)==(round*(this.koloniAdet-1)))
							koloniler[i].savas_kaybetme-= this.koloniAdet-1;
					}
					else{
						if((koloniler[i].savas_kazanma+koloniler[i].savas_kaybetme)==(round*(this.koloniAdet-1)))
						koloniler[i].savas_kazanma-= this.koloniAdet-2;
					}					
					koloniler[i].EkranaYazdir(num_alive);	
				}
				System.out.println("----------------------------------------------------------");		
				break ;
			}
		
		
			// her turda veriler ekrana yazdiriliyor
			System.out.println("----------------------------------------------------------");
			System.out.println("Tur Sayisi: "+round);
			System.out.println("KOLONI  POPULASYON     YEMEK STOGU      KAZANMA   KAYBETME");
			for (int i = 0; i < this.koloniAdet; i++) {
				koloniler[i].EkranaYazdir(num_alive);
			}
			System.out.println("----------------------------------------------------------");

		
			round++; // Bir sonraki tur için round değişkenini arttır
		}
	}
}