/**
*
* @author Mehmet ATAS mehmet.atas5@ogr.sakarya.edu.tr
* @since 25.05.2023
* <p>
* Main fonksiyonu, uygulamanın ana girdi noktasi
* </p>
*/
package g201210382_3;
public class Program {
	public static void main(String[] args) {
		Oyun oyun = new Oyun(); 	
		oyun.OyunBaslat();        
	}
}	