/**
*
* @author Mehmet ATAS mehmet.atas5@ogr.sakarya.edu.tr
* @since 24.05.2023
* <p>
* Soyut olarak olusturulacak olan savas fonksiyonunu iceren abstract sınıf
* </p>
*/
package g201210382_3;
public abstract class Taktik {
	public int SavasFonksiyonu(){
		return Savas();
	}
	// soyut olarak olusturulacak olan Savas fonk.
	public abstract int Savas();
}
