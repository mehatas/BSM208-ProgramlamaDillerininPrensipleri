/**
*
* @author Mehmet ATAŞ mehmet.atas5@ogr.sakarya.edu.tr
* @since 24.05.2023
* <p>
* 	Kullanıcıdan alınan veriler arasında geçersiz karakter olup olmadığını kontrol etmemizi sağlayan fonksiyonu içeren sınıf
* </p>
*/
package g201210382_3;

public class KarakterKontrol {
	public static boolean karakterKontrol(String str) {
	    for (char c : str.toCharArray()) {
	        if (!Character.isDigit(c)) {
	            return true; // Sayısal olmayan karakterler var
	        }
	    }
	    return false; // Geçerli bir sayı
	}
}
