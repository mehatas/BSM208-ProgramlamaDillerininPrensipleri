/**
*
* @author Mehmet ATAS mehmet.atas5@ogr.sakarya.edu.tr
* @since 24.05.2023
* <p>
* 	Soyut uretim fonksiyonunun 1-10 arasında değer döndürmesini sağlayan işlemler yapılıyor, Uretim sınıfından kalıtım alınmaktadır 
* </p>
*/
package g201210382_3;
import java.util.Random;
public class AUretim extends Uretim{
	public AUretim() {
		super();
	}
	
	@Override
	public int uretim(){
		Random rand = new Random();
		int a = rand.nextInt(100);
		int b = rand.nextInt(250);
		int c = rand.nextInt(500);
		int d = rand.nextInt(1000);;
		
		return ((a*d)+(b*c))%10+1;//1-10 arasında rastgele bir deger dondurur
		
	}
}
