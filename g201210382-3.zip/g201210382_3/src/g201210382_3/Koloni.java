/**
*
* @author Mehmet ATAŞ mehmet.atas5@ogr.sakarya.edu.tr
* @since 25.05.2023
* <p>
* 	Kolonilerin oluşturuluduğu koloni kurucu,ekrana yazdir, koloni besle, koloni nufus artisi ve koloni yemek uretim fonksiyonlarını içeren Koloni sınıfı
* </p>
*/
package g201210382_3;

public class Koloni {
	public int nufus;
	public int sembol;
	public int yemek;
	public int savas_degeri;
	public int savas_kazanma;
	public int savas_kaybetme;
	
	public Koloni(int nufus,int sembol,int savas_degeri,int savas_kaybetme,int savas_kazanma,int yemek){	
		this.nufus=nufus;
		this.sembol=sembol;
		this.savas_degeri=savas_degeri;
		this.savas_kaybetme=savas_kaybetme;
		this.savas_kazanma=savas_kazanma;
		this.yemek=yemek;
	}
	public void EkranaYazdir(int deger) {
	    if (deger <= 1) {
	        if (nufus <= 0 || yemek <= 0) {
	            System.out.printf("  %-6c  %-12s   %-14s   %-8s  %-8s\n", (char)sembol, "--", "--", "--", "--");
	        } else {
	            System.out.printf("  %-6c  %-12d   %-14d   %-8d  %-8d\n", (char)sembol, nufus, yemek, savas_kazanma, savas_kaybetme);
	        }
	    } else {
	        System.out.printf("  %-6c  %-12d   %-14d   %-8d  %-8d\n", (char)sembol, nufus, yemek, savas_kazanma, savas_kaybetme);
	    }
	}
	public void koloniBesle(Koloni a){
		if (a.nufus > 0 && a.yemek > 0) {
			a.yemek -= a.nufus * 2;
		}
	}
	public void koloniNufus(Koloni a) {
		if (a.nufus > 0 && a.yemek > 0) {
			a.nufus += a.nufus * 0.4;
		}
	}
	// her koloni rastgele soyut olarak olusturulan uretim(auretim ve buretim) fonksiyonu yardımıyla uretim yapar
	public void Uret(Koloni a, int i) {
		if (a.nufus > 0 && a.yemek > 0) {
			if (i % 2 == 0) {
				AUretim aUret = new AUretim();
				a.yemek += aUret.UretimFonksiyonu();
			} else {
				BUretim bUret = new BUretim();
				a.yemek += bUret.UretimFonksiyonu();
			}
        } 
     } 
}
